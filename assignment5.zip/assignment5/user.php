
<!DOCTYPE html>
<?php

$cookie_value = "User Page";
setcookie("cookie[1]", $cookie_value, time() + (86400 * 30)); // 86400 = 1 day
?>
<html lang="en">
<head>
  <title>Login V15</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
  <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor1/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor1/animate/animate.css">
<!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="vendor1/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor1/animsition/css/animsition.min.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor1/select2/select2.min.css">
<!--===============================================================================================-->  
  <link rel="stylesheet" type="text/css" href="vendor1/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body >
  
  <div class="limiter" style="background-image : url(images/elliEx.png);">

     
    <div class="container-login100"  >
      <div class="wrap-login100"   >
        <div class="login100-form-title" style="background-image: url(images/heading.png);color: blue;">
          <span class="login100-form-title-1">
            Create User
          </span>
        </div>

        <form class="login100-form validate-form" action = "insert.php" method = "post">
           <div class="wrap-input100 validate-input m-b-26" data-validate="First Name is required">
            <span class="label-input100">First Name</span>
            <input class="input100" type="text" name="firstname" placeholder="Enter your First name">
            <span class="focus-input100"></span>
          </div>

           <div class="wrap-input100 validate-input m-b-26" data-validate="Last Name is required">
            <span class="label-input100">Last name</span>
            <input class="input100" type="text" name="lastname" placeholder="Enter your Last Name">
            <span class="focus-input100"></span>
          </div>
           
            <div class="wrap-input100 validate-input m-b-26" data-validate="Email is required">
            <span class="label-input100">Email</span>
            <input class="input100" type="email" name="email" placeholder="Enter your Email which is your username as well">
            <span class="focus-input100"></span>
          </div>


          <div class="wrap-input100 validate-input m-b-26" data-validate="Home address is required">
            <span class="label-input100">Home address</span>
            <input class="input100" type="text" name="homeaddress" placeholder="Enter your address">
            <span class="focus-input100"></span>
          </div>

          <div class="wrap-input100 validate-input m-b-18" data-validate = "Phone number is required">
            <span class="label-input100">Phone Number</span>
            <input class="input100" type="number" name="number" placeholder="Enter your phone number">
            <span class="focus-input100"></span>
          </div>

           <div class="wrap-input100 validate-input m-b-18" data-validate = "Cell number is required">
            <span class="label-input100">Cell Number</span>
            <input class="input100" type="number" name="cellnumber" placeholder="Enter your cell number">
            <span class="focus-input100"></span>
          </div>
        <!--  <div class="flex-sb-m w-full p-b-30">
            <div class="contact100-form-checkbox">
              <input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
              <label class="label-checkbox100" for="ckb1">
                Remember me
              </label>
            </div>

            <div> -->
              <!-- <a href="#" class="txt1">
                Forgot Password?
              </a>
            </div>
          </div> -->
 
          <div class="container-login100-form-btn">
            
         <div >
            <button class="login100-form-btn" type = "submit" 
               name = "create">
              Create User
            </button>

          </div>
             &nbsp; &nbsp; &nbsp; &nbsp;
          <div>

            <button class="login100-form-btn" type = "submit" 
               name = "cancel" onClick="window.location.href='production/go.php'">
              Search User
            </button>
          </div>
            </br>
            </br>
            </br>
             <div>

            <button class="login100-form-btn" type = "submit" 
               name = "cancel" onClick="window.location.href='production/view.php'">
              All User
            </button>
          </div>
          

         
        </div>

         
           
          
          


              <div class = "container login100">
         
        
      </div> 
          

        </form>
      </div>
    </div>
  </div>
  
<!--===============================================================================================-->
  <script src="vendor1/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
  <script src="vendor1/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
  <script src="vendor1/bootstrap/js/popper.js"></script>
  <script src="vendor1/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
  <script src="vendor1/select2/select2.min.js"></script>
<!--===============================================================================================-->
  <script src="vendor1/daterangepicker/moment.min.js"></script>
  <script src="vendor1/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
  <script src="vendor1/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
  <script src="js/main.js"></script>

</body>
</html>