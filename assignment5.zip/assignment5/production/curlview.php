<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Gentelella Alela! | </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
   <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
   

            <?php
           $servername = "localhost";
           $username = "root";
           $password = "nirajniket";
           $dbname = "272";

          // Create connection
          $conn = new mysqli($servername, $username, $password, $dbname);
          // Check connection
          if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
           }

           $result = $conn->query("SELECT *  FROM a",MYSQLI_USE_RESULT);
           
             ?>

           


        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                
              </div>

             </div>
           </div>
                
              
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                 <span class="input-group-btn">
                      <button class="btn btn-primary" name="submit" type="submit" value="Search" onClick="window.location.href='../index.php'">Home</button>
                    </span>
                   <span class="input-group-btn">
                      <button class="btn btn-primary" name="submit" type="submit" value="Search" onClick="window.location.href='view.php'">My Users</button>
                    </span>
                    <span class="input-group-btn">
                      <button class="btn btn-primary" name="submit" type="submit" value="Search" onClick="window.location.href='curltrial.php'">Load Users</button>
                    </span>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                   <form action="search.php" method="post">
                  <div class="input-group">
                    <!-- <form action="search.php" method="post">
                    <input type="text" class="form-control" name="search" placeholder="Search name...">
                    <span class="input-group-btn">
                      <button class="btn btn-primary" name="submit" type="submit" value="Search">Go!</button>
                    </span> -->
                  
                  </div>
                  </form>
                </div>
              </div>
            </div>
               

              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>List of Users in Kailash's Database</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      
                      
                        </ul>
                      
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>UserId</th>
                          <th>First Name</th>
                          <th>Last Name</th>
                          <th>Email</th>
                          <th>Home Address</th>
                          <th>Home Phone</th>
                          <th>Cell No</th>
                        </tr>
                      </thead>
                      <tbody>
                       

                         <?php
               while ($row = $result->fetch_assoc()) {?>
                   <tr>
                   <td><?php echo htmlentities($row['user_id']);?></td>
                   <td><?php echo htmlentities($row['first_name']);?></td>
                   <td><?php echo htmlentities($row['last_name']);?></td>
                   <td><?php echo htmlentities($row['email']);?></td>
                   <td><?php echo htmlentities($row['address']);?></td>
                   <td><?php echo htmlentities($row['home']);?></td>
                   <td><?php echo htmlentities($row['cell']);?></td>
                   </tr>
              <?php  } ?>
                       
                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
  

   
             
            
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
       
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>