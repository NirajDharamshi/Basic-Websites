<?php

 $servername = "localhost";
           $username = "root";
           $password = "1234";
           $dbname = "272";

          // Create connection
          $conn = new mysqli($servername, $username, $password, $dbname);
          // Check connection
          if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
           }

           $result = $conn->query("SELECT *  FROM product",MYSQLI_USE_RESULT);


               while ($row = $result->fetch_assoc()) {
                   
                   echo $row['name']."|".$row['description']."|".$row['price']."|".$row['link']."\n";
                  

               }
                   
              
?>