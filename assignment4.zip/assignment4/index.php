<!DOCTYPE html>
<?php

$cookie_value = "Home Page";
setcookie("cookie[0]", $cookie_value, time() + (86400 * 30)); // 86400 = 1 day
?>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>elliEx</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href="css/agency.min.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">elliEx</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav text-uppercase ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#">Home</a>
            </li>
             <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#news">News</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#services">Products</a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#about">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#contact">Contact</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="login.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="user.php">Users</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#cookie">Cookies</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead">
      <div class="container">
        <div class="intro-text">
          <div class="intro-lead-in">Magnifying your business possibilities </div>
          <div class="intro-heading text-uppercase">with disrupting technologies</div>
          <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#news">Latest News</a>
        </div>
      </div>
    </header>

      <!-- News -->
    <section id="news">
      <div class="container">

      <!--    <h2 class="section-heading text-uppercase">News</h2>
         <div class="container"> -->
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Latest News</h2>
            <div id="wrapper">
  <div id="three-column" class="container">
      <div class="banner">
          <img src="images/pic01.jpg" alt="" />
        </div>
    <div class="title">
      <h2>Multi Organization architecture</h2>
      <span class="byline">New feature with hierarchial approach has been rolled out for organising teams of organization.</span>
    </div>
      <div class="title">
      <h2>Mailing System</h2>
      <span class="byline">Auto email trigering has been introduced for all the outbound transactions enhancing customer experience and streamlining core services.</span>
    </div>
      <div class="title">
      <h2>Auto-Payment Settlement</h2>
      <span class="byline">Auto payment settlement allows scheduled pay,ent of due bills which eliminates account payables intricacies to maintain book and track due dates.</span>
    </div>
   
    
    
  </div>
</div>

          </div>
        </div>

          </div>
          </div>
           </section>




    <!-- Services -->
    <section id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Products</h2>
            <h3 class="section-subheading text-muted">Cutting edge solutions to power your dreams</h3>
          </div>
        </div>
        <div class="row text-center">
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/ecomm.php">E-Commerce Web Design</a></h4>
            <p class="section-subheading text-muted"><a href="production/ecomm.php">We design e-commerce whole stack systems from scratch,no wonder they are awesome.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-laptop fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/Webapp.php">Web Apps for Businesses</a></h4>
            <p class="text-muted"><a href="production/Webapp.php">We design webapps for businesses tailored to your operations,its definitely a weapon.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/security.php">Security Solution</a></h4>
            <p class="text-muted"><a href="production/security.php">We deliver security solution for computer systems & networks.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/cloud.php">Cloud Solutions</a></h4>
            <p class="text-muted"><a href="production/cloud.php">We deliver Cloud Consulting & Solutions.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/ai.php">AI Solutions</a></h4>
            <p class="text-muted"><a href="production/ai.php">We deliver AI solution</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/ml.php">ML Solution</a></h4>
            <p class="text-muted"><a href="production/ml.php">We deliver ML consulting.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/embedded.php">Embedded Solution</a></h4>
            <p class="text-muted"><a href="production/embedded.php">We deliver emdedded solution.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/model.php">Modelling Services</a></h4>
            <p class="text-muted"><a href="production/model.php">We deliver Modelling & Software Solution.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/network.php">Networking Solution</a></h4>
            <p class="text-muted"><a href="production/network.php">We deliver networking solutions.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/seo.php">SEO Optimization</a></h4>
            <p class="text-muted"><a href="production/seo.php">We deliver SEO Solution.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/virtual.php">Virtualization </a></h4>
            <p class="text-muted"><a href="production/virtual.php">We deliver virtualization solution.</a></p>
          </div>
          <div class="col-md-4">
            <span class="fa-stack fa-4x">
              <i class="fa fa-circle fa-stack-2x text-primary"></i>
              <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
            </span>
            <h4 class="service-heading"><a href="production/data.php">Data Warehousing Solution</a></h4>
            <p class="text-muted"><a href="production/data.php">We deliver data warehousing solution</a></p>
          </div>
        </div>
      </div>
    </section>

   

    <!-- About -->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">About</h2>
            <h3 class="section-subheading text-muted">dream to change the world takes birth</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <ul class="timeline">
              <li>
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/1.jpg" alt="">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>2015-2016</h4>
                    <h4 class="subheading">Our Humble Beginnings</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">Search for opportunities in the lanes of Mumbai begins</p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/2.jpg" alt="">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>March 2016</h4>
                    <h4 class="subheading">First Product is developed.</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">New gen products to serve ever complicated world is contemplated and developed with market needs in mind.</p>
                  </div>
                </div>
              </li>
              <li>
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/3.jpg" alt="">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>December 2016</h4>
                    <h4 class="subheading">Customer Base grows to 1000</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">Just a begining!</p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/4.jpg" alt="">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>July 2017</h4>
                    <h4 class="subheading">Technological Innovations!</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">Highly Flexible models are built ushering new era of tailored drag and drop applications!</p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <h4>Be Part
                    <br>Of Our
                    <br>Story!</h4>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

 

    <!-- Contact -->
<section id="contact">

 <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Contact Us</h2>
           <div class="section-heading text-uppercase"> <?php
                $file = "./contacts.txt";
                $f = fopen($file, "r") or exit("Unable to open file!");

                while(!feof($f))
                  {
                     echo fgets($f)."<br />";
                   }

                    fclose($f);
                     ?>
            
          </div>
          </div>
        </div>
    
    </section>

    <section id="cookie">

 <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Visited Pages</h2>
           <div class="section-heading text-uppercase"> 
            <?php
if(!isset($_COOKIE['cookie'])) {
    echo "Cookie named '" . $cookie . "' is not set!";
} else {
  
    foreach ($_COOKIE['cookie'] as $name => $value) {
        $name = htmlspecialchars($name);
        $value = htmlspecialchars($value);
        echo "$value <br />\n";

    }
}
?>


            
          </div>
          </div>
        </div>
    
    </section>

    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <span class="copyright">Copyright &copy; Your Website 2018</span>
          </div>
          <div class="col-md-4">
            <ul class="list-inline social-buttons">
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-twitter"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-facebook"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="list-inline quicklinks">
              <li class="list-inline-item">
                <a href="#">Privacy Policy</a>
              </li>
              <li class="list-inline-item">
                <a href="#">Terms of Use</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>

    

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/agency.min.js"></script>

  </body>

</html>
