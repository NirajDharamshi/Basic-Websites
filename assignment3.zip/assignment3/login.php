<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V15</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor1/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor1/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor1/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor1/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor1/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor1/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body >
	
	<div class="limiter" style="background-image : url(images/elliEx.png);">


		<div class="container-login100"  >
			<div class="wrap-login100"   >
				<div class="login100-form-title" style="background-image: url(images/heading.png);color: blue;">
					<span class="login100-form-title-1">
						Sign In
					</span>
				</div>

				<form class="login100-form validate-form" action = "" method = "post">
					<div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">Username</span>
						<input class="input100" type="text" name="username" placeholder="Enter username">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="password" placeholder="Enter password">
						<span class="focus-input100"></span>
					</div>

				<!-- 	<div class="flex-sb-m w-full p-b-30">
						<div class="contact100-form-checkbox">
							<input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
							<label class="label-checkbox100" for="ckb1">
								Remember me
							</label>
						</div>

						<div> -->
							<!-- <a href="#" class="txt1">
								Forgot Password?
							</a>
						</div>
					</div> -->
 
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" type = "submit" 
               name = "login">
							Login
						</button>
					</div>
							<div class = "container login100">
         
         <?php
            $msg = '';
            
            if (isset($_POST['login']) && !empty($_POST['username']) 
               && !empty($_POST['password'])) {
				
				$file="userid.csv";
			   if(!$file=fopen("userid.csv","r"))
			   {  
			   	echo 'File is not present';
			   }
			   else{
			    while(!feof($file))
			    {
			    	$line=fgets($file,255);
			    	$line=chop($line);
			    	$field=explode(",",$line,2);

			    	if($_POST['username']==$field[0])
			    	  {
			    	  	if($_POST['password']==$field[1])
			    	  	{
			    	  		
                             header("Location: production/view.php");
                             
                             die(); 
			    	  	}
			    		else
			    	  	{		
			    	      
			    	      break;
			    	      
			    	  	}
			    	  }
			    	  else
			    	  {
			    	  	
			    	  	continue;
			    	  }

			    }

			    echo"<script type='text/javascript'>alert('Invalid username or password');</script>";
			}
			}
               /*if ($_POST['username'] == 'admin' && 
                  $_POST['password'] == 'admin') {
                  
                  echo 'You have entered valid use name and password';
                  header("Location: access.php");
                  die();
               }else
               if(empty($_POST['username']))
               {echo 'Please enter userid';}
               else if (empty($_POST['password'])) {
               	echo 'Please enter password';
               } else
               {
                  echo "<script type='text/javascript'>alert('Invalid User or password');</script>";
                }
               }*/
            
         ?>
      </div> 
					

				</form>
			</div>
		</div>
	</div>
	
<!--===============================================================================================-->
	<script src="vendor1/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor1/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor1/bootstrap/js/popper.js"></script>
	<script src="vendor1/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor1/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor1/daterangepicker/moment.min.js"></script>
	<script src="vendor1/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor1/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>