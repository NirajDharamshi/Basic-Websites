<?php
$servername = "localhost";
$username = "root";
$password = "nirajniket";
$dbname = "272";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$firstname=mysqli_real_escape_string($conn, $_REQUEST['firstname']);
$lastname=mysqli_real_escape_string($conn, $_REQUEST['lastname']);
$email=mysqli_real_escape_string($conn, $_REQUEST['email']);
$homeaddress=mysqli_real_escape_string($conn, $_REQUEST['homeaddress']);
$number=mysqli_real_escape_string($conn, $_REQUEST['number']);
$cellnumber=mysqli_real_escape_string($conn, $_REQUEST['cellnumber']);

$sql = "INSERT INTO users (first_name, last_name, email,address,home,cell) VALUES ('$firstname','$lastname','$email','$homeaddress','$number','$cellnumber')";

if ($conn->query($sql) === TRUE) {
	echo"<script type='text/javascript'>alert('User Created!');</script>";
    	

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

echo "<script>location.href='index.php';</script>";
$conn->close();
?>